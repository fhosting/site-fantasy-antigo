<?php

session_start();

header_remove('X-Powered-By');
header("X-XSS-Protection: 1; mode=block");
header("X-WebKit-CSP: policy");
header('Content-Type: text/html; charset=utf-8');

# locality
setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
date_default_timezone_set('America/Sao_Paulo');

// [ General ]

# requests
require_once 'vendor/helper/autoload.php';
require_once 'vendor/autoload.php';

# class
use assets\content\lib\grade\System;
use assets\content\lib\grade\Config;

# variables
$system = new System();
$config = new Config();

# global definitions
define("BASE_URL", Config::BASE_URL);
define("APP_ROOT", "https://{$_SERVER['HTTP_HOST']}'/");
define("SITE_NAME", Config::SITE_NAME);
define("SITE_NAME_M", Config::SITE_NAME_M);
define("SITE_KEYWORDS", "g. moehra, gmoehra, geraldo, geraldo moehra, geraldo m, gm, gmods, gj, sites, minecraft, minecraft coding, web, site, bungeecord, waterfall, servidor, sistemas, hospedagem minecraft, host, fantasyhost, fantasy host");
define("SITE_COLOR", "#ba00b4");
define("DATE_FORMAT", "d/m/Y - H:i:s");

// [ Others ]

# show erros
if ($config::DEBUG) {
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);
}

$system->setup();

?>