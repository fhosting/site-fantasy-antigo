(function($) {
    "use strict"; // Start of use strict

    // Smooth scrolling using jQuery easing
    $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
        if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                $('html, body').animate({
                    scrollTop: (target.offset().top - 54)
                }, 1000, "easeInOutExpo");
                return false;
            }
        }
    });

    // Closes responsive menu when a scroll trigger link is clicked
    $('.js-scroll-trigger').click(function() {
        $('.navbar-collapse').collapse('hide');
    });

    // Activate scrollspy to add active class to navbar items on scroll
    $('body').scrollspy({
        target: '#mainNav',
        offset: 56
    });

    // Collapse Navbar
    var navbarCollapse = function() {
        if ($("#mainNav").offset().top > 100) {
            $("#mainNav").addClass("navbar-shrink");
        } else {
            $("#mainNav").removeClass("navbar-shrink");
        }
    };
    // Collapse now if page is not at top
    navbarCollapse();
    // Collapse the navbar when page is scrolled
    $(window).scroll(navbarCollapse);

    // Hide navbar when modals trigger
    $('.portfolio-modal').on('show.bs.modal', function(e) {
        $(".navbar").addClass("d-none");
    })
    $('.portfolio-modal').on('hidden.bs.modal', function(e) {
        $(".navbar").removeClass("d-none");
    })

})(jQuery); // End of use strict

// Faz o check de player
$('#form').submit(function(e) {
    $.post('data.php?arg=checar_player', $(this).serialize(), function(data) {
        $('#result .modal-body').html(data)
        $('#result').modal()
    })
    e.preventDefault()
})

// Esconde ou mostra input id e discord
$('#selectForm').change(function() {
    if ($(this).val() == 'discord') {
        $('#formDiscord').removeClass("d-none");
        $('#formId').addClass("d-none");
        document.getElementById("formId").disabled = true;
        document.getElementById("formDiscord").disabled = false;
        document.getElementById("modal-size").style.maxWidth = "90%";

    } else {
        $("#formId").removeClass("d-none");
        $("#formDiscord").addClass("d-none");
        document.getElementById("formDiscord").disabled = true;
        document.getElementById("formId").disabled = false;
        document.getElementById("modal-size").style.maxWidth = "500px";
    }
});


// Faz o check do chat ilegal
$('#form_ilegal').submit(function(e) {
    $.post('data.php?arg=chat_ilegal', $(this).serialize(), function(data) {
        $('#text_chat_ilegal').html(data)
        $("#section_chat_ilegal").removeClass("d-none");
    })
    e.preventDefault()
})

// Restart
$('#restart').submit(function(e) {
    $.post('functions.php', $(this).serialize(), function(data) {
        $('#result .modal-body').html(data)
        $('#result').modal()
    })

    e.preventDefault()

})

// Apresenta resultado da whitelist
$('#formwhitelist').submit(function(e) {
    $.post('formwhitelist.php', $(this).serialize(), function(data) {
        $('#result .modal-body').html(data)
        $('#result').modal()
        grecaptcha.reset();
    })

    e.preventDefault()

})

// Retorna a ativação de vip
$('#vipactivator-form').submit(function(e) {
    $.post('vipactivator.php', $(this).serialize(), function(data) {
        $('#result .modal-body').html(data)
        $('#result').modal()
    })

    e.preventDefault()

})

$('#vipdisable-form').submit(function(e) {
    $.post('vipdisable.php', $(this).serialize(), function(data) {
        $('#result .modal-body').html(data)
        $('#result').modal()
    })

    e.preventDefault()

})

// Checar VIP
$('#check-vip').submit(function(e) {
        var capture_id = $('#capture_id').val();

        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'checar-vip', capture_id: capture_id }
        }).done(function(data) {
            $('#result .modal-body').html(data)
            $('#result').modal()
        });

        e.preventDefault()

    })
    // banir old
$('#ban-form').submit(function(e) {
    $('#page-top').loading('start')
    $.post('ban.php', $(this).serialize(), function(data) {
        $('#page-top').loading('stop')
        $('#result .modal-body').html(data)
        $('#result').modal()

    })

    e.preventDefault()

})

// desbanir old
$('#desban-form').submit(function(e) {
        $.post('desban.php', $(this).serialize(), function(data) {
            $('#result .modal-body').html(data)
            $('#result').modal()
        })

        e.preventDefault()

    })
    // Banir NOVO
function banir() {
    var id = document.getElementsByName("id")[0].value
    if (id == '') {
        alert("Você precisa preencher um id!")
    } else {
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'banir', id: id }
        }).done(function(data) {
            $('#result .modal-body').html(data)
            $('#result').modal()
        });
    }
}

// Desbanir NOVO
function desbanir() {
    var id = document.getElementsByName("id")[0].value
    if (id == '') {
        alert("Você precisa preencher um id!")
    } else {
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'desbanir', id: id }
        }).done(function(data) {
            $('#result .modal-body').html(data)
            $('#result').modal()
        });
    }
}

// Kickar NOVO
function kickar() {
    var id = document.getElementsByName("id")[0].value
    if (id == '') {
        alert("Você precisa preencher um id!")
    } else {
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'kickar', id: id }
        }).done(function(data) {
            $('#result .modal-body').html(data)
            $('#result').modal()
        });
    }
}

// Ligar servidor
function sv_start() {
    var e = document.getElementById("servidor");
    var sv = e.options[e.selectedIndex].value;

    if (sv === 'undefined') {
        alert("Você precisa escolher um servidor!")
    } else {
        $('#page-top').loading('start')
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'sv_control', sv: sv, fun: 1 }
        }).done(function(data) {
            $('#result .modal-body').html(data)
            $('#result').modal()
            $('#page-top').loading('stop')
        });
    }
}

// Desligar servidor
function sv_stop() {
    var e = document.getElementById("servidor");
    var sv = e.options[e.selectedIndex].value;

    if (sv === 'undefined') {
        alert("Você precisa escolher um servidor!")
    } else {
        $('#page-top').loading('start')
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'sv_control', sv: sv, fun: 0 }
        }).done(function(data) {
            $('#result .modal-body').html(data)
            $('#result').modal()
            $('#page-top').loading('stop')
        });
    }
}

// Reiniciar servidor
function sv_restart() {
    var e = document.getElementById("servidor");
    var sv = e.options[e.selectedIndex].value;

    if (sv === 'undefined') {
        alert("Você precisa escolher um servidor!")
    } else {
        $('#page-top').loading('start')
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'sv_control', sv: sv, fun: 2 }
        }).done(function(data) {
            $('#result .modal-body').html(data)
            $('#result').modal()
            $('#page-top').loading('stop')
        });
    }
}


$(document).ready(function() {
    $("#vip").change(function() {
        if ($(this).val() == "vip-basic") {
            $("#homes").addClass("d-none");
            $("#homest").addClass("d-none");
        } else {
            $("#homes").removeClass("d-none");
            $("#homest").removeClass("d-none");
        }
    });
});


// Aqui some com botao casa quando nao vai setar casa sets
$(document).ready(function() {
    $("#nohomes").change(function() {
        if ($(this).is(":checked")) {
            $("#homes").addClass("d-none");
            $("#homest").addClass("d-none");
        } else {
            $("#homes").removeClass("d-none");
            $("#homest").removeClass("d-none");

        }
    });
});

// Verificar players online
if (location.pathname == '/players.html') {
    $(document).ready(function() {
        $('#page-top').loading('start')
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'onlineplayers' }
        }).done(function(data) {
            $('#player_list').html(data)
            $('#page-top').loading('stop')
                //
            var sv1 = false
            $('#btn_Server_1').click(function(event) {
                event.preventDefault();
                sv1 = !sv1
                if (sv1 == true) {
                    $('#Server_1').fadeIn(200);
                } else {
                    $('#Server_1').fadeOut(200);
                }
            });

            // SV2
            var sv2 = false
            $('#btn_Server_2').click(function(event) {
                event.preventDefault();
                sv2 = !sv2
                if (sv2 == true) {
                    $('#Server_2').fadeIn(200);
                } else {
                    $('#Server_2').fadeOut(200);
                }
            });
            //SV3
            var sv3 = false
            $('#btn_Server_3').click(function(event) {
                event.preventDefault();
                sv3 = !sv3
                if (sv2 == true) {
                    $('#Server_3').fadeIn(200);
                } else {
                    $('#Server_3').fadeOut(200);
                }
            });
            //Eventos
            var svEv = false
            $('#btn_Server_Eventos').click(function(event) {
                event.preventDefault();
                svEv = !svEv
                if (svEv == true) {
                    $('#Server_Eventos').fadeIn(200);
                } else {
                    $('#Server_Eventos').fadeOut(200);
                }
            });
            //

        });
    })
}

// Checar ban desban
if (location.pathname == '/checar-bans.html') {

    $(document).ready(function() {
        $('#page-top').loading('start')
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'checar_bans' }
        }).done(function(data) {
            $('#ban-list').html(data)
            $('#page-top').loading('stop')
        });
    })
}

// Painel Administrativo
// Carrega lista de contas ativas



function changeButtonEntrar() {
    $('#btn-entrar').html('PAINEL')
    $('#btn-entrar').attr("href", "panel.html");
}

$(document).ready(function() {
    if (Boolean(getCookie('auth_admin'))) {
        changeButtonEntrar();

        if (location.pathname == '/panel.html') {
            $("#panel-playerson").removeClass("d-none");
            $("#panel-ilegal").removeClass("d-none");
            $("#panel-check").removeClass("d-none");
            $("#panel-banir").removeClass("d-none");
            $("#panel-desbanir").removeClass("d-none");
            $("#panel-checkbans").removeClass("d-none");
            $("#panel-adicionarvip").removeClass("d-none");
            $("#panel-listarvips").removeClass("d-none");
            $("#panel-movimentacao").removeClass("d-none");
            $("#panel-gerenciarsv").removeClass("d-none");
            $("#panel-recuperarconta").removeClass("d-none");
            $("#panel-vipchanges").removeClass("d-none");
            $("#panel-addquestion").removeClass("d-none");
            $("#panel-editquestion").removeClass("d-none");
            $("#painel-administrativo").slideDown(300);
        }

    } else if (Boolean(getCookie('auth_chefe'))) {
        changeButtonEntrar();

        if (location.pathname == '/panel.html') {
            $("#panel-playerson").removeClass("d-none");
            $("#panel-ilegal").removeClass("d-none");
            $("#panel-check").removeClass("d-none");
            $("#panel-banir").removeClass("d-none");
            $("#panel-desbanir").removeClass("d-none");
            $("#panel-checkbans").removeClass("d-none");
            $("#panel-movimentacao").removeClass("d-none");
            $("#panel-gerenciarsv").removeClass("d-none");
            $("#panel-recuperarconta").removeClass("d-none");
            $("#panel-addquestion").removeClass("d-none");
            $("#panel-editquestion").removeClass("d-none");
            $("#painel-administrativo").slideDown(300);
        }
        // Sem permissão
        if (location.pathname == '/lista-vips.html' || location.pathname == '/sets.html' || location.pathname == '/changes.html') {
            $("html").html('');
            location.href = '/entrar.html'
        }

    } else if (Boolean(getCookie('auth_manager'))) {
        changeButtonEntrar();

        if (location.pathname == '/panel.html') {
            $("#panel-playerson").removeClass("d-none");
            $("#panel-ilegal").removeClass("d-none");
            $("#panel-check").removeClass("d-none");
            $("#panel-banir").removeClass("d-none");
            $("#panel-desbanir").removeClass("d-none");
            $("#panel-checkbans").removeClass("d-none");
            $("#panel-movimentacao").removeClass("d-none");
            $("#panel-recuperarconta").removeClass("d-none");
            $("#painel-administrativo").slideDown(300);
        }
        // Sem permissão
        if (location.pathname == '/lista-vips.html' || location.pathname == '/sets.html' || location.pathname == '/changes.html') {
            $("html").html('');
            location.href = '/entrar.html'
        }

    } else if (Boolean(getCookie('auth_viewer'))) {
        changeButtonEntrar();

        if (location.pathname == '/panel.html') {
            $("#panel-playerson").removeClass("d-none");
            $("#panel-ilegal").removeClass("d-none");
            $("#panel-check").removeClass("d-none");
            $("#panel-movimentacao").removeClass("d-none");
            $("#painel-administrativo").slideDown(300);
        }
        // Sem permissão
        if (location.pathname == '/lista-vips.html' || location.pathname == '/sets.html' || location.pathname == '/changes.html') {
            $("html").html('');
            location.href = '/entrar.html'
        }

    } else {
        if (location.pathname != '/index.html' && location.pathname != '/donators.html' && location.pathname != '/whitelist.html' && location.pathname != '/whitelist-beta.html') {
            if (location.pathname != '/entrar.html') {
                $('html').html('');
                location.href = '/entrar.html'
            }
        }
    }
});


function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


// Carrega lista de contas ativas
if (location.pathname == '/lista-vips.html') {

    $(document).ready(function() {
        //$('#lista-vips').hide()
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'lista_vips' }
        }).done(function(data) {
            $('#tabela-vips').html(data)
            $('#lista-vips').slideDown(1000)
        });
        // Quantidade de vips ativos
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'qtd_vips_ativos' }
        }).done(function(data) {
            $('#qtd_vips_ativos').html(data);
        });
        // Valor dos vips neste mes
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'valor_vips_mes' }
        }).done(function(data) {
            obj = JSON.parse(data);
            $('#valor_vips_mes').html(obj.lucro);
            $('#valor_vips_prev').html(obj.previsao);
        });
    })

}

// Carrega movimentacao financeira
if (location.pathname == '/movimentacao-financeira.html') {

    $(document).ready(function() {
        //$('#lista-vips').hide()
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'movimentacao_financeira' }
        }).done(function(data) {
            $('#lista-movimentacao').html(data)
            $('#lista-movimentacao').slideDown(1000)
        });

    });
}



// Desabilitar vip
function disable_vip(hash) {
    var r = confirm("Deseja desabilitar este vip?");
    if (r == true) {
        $.ajax({
            url: '/data.php',
            method: 'get',
            data: { arg: 'disable_vip', hash: hash }
        }).done(function(data) {
            alert(data);
            location.reload()
        });
    }

}

// Limpar pesquisa
$('#clear-search').on('search', function(e) {
    if ('' == this.value) {

        $('.results tbody tr').attr('visible', 'true');
        $('.no-result').attr('visible', 'false').removeAttr('style');
    }
});

// buscas da tabela
$(document).ready(function() {
    $(".search").keyup(function() {
        var searchTerm = $(".search").val();
        var listItem = $('.results tbody').children('tr');
        var searchSplit = searchTerm.replace(/ /g, "'):containsi('")

        $.extend($.expr[':'], {
            'containsi': function(elem, i, match, array) {
                return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
            }
        });

        $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e) {
            $(this).attr('visible', 'false');
        });

        $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e) {
            $(this).attr('visible', 'true');
        });

        var jobCount = $('.results tbody tr[visible="true"]').length;
        //$('.counter').text(jobCount + ' item');
        console.log(jobCount)
        if (jobCount == '0') { $('.no-result').show(); } else { $('.no-result').hide(); }
    });
});

// Mostra imagem do carro ao passar o mouse
$(document).ready(function() {
    $('label').hover(function() {
        var img = $(this).find('input').val();
        $("#img_preview").attr('src', '/assets/img/carros/' + img + '.png');
        $('#block-preview').removeClass('d-none');
    })

    //$('.checkbox input:checkbox').mouseover(function() {console.log(this.value)
    //var img = this.value;
    //$("#img_preview").attr('src','/assets/img/carros/' + img + '.png');
    //$('#block-preview').removeClass('d-none');
    //})
})

$(document).ready(function() {
    $('label').mouseout(function() {
        $('#block-preview').addClass('d-none');
    })
})

/////// Black frauday

// Verificar players online
//if (location.pathname == '/' || location.pathname == '/index.html' ) {
//	
//	$(document).ready(function(){
//		$('#black').modal()
//	})
//}


// Recovery Recuperar conta

$('#recovery').submit(function(e) {
    $.post('data.php?arg=recoveryCheck', $(this).serialize(), function(data) {

        var idOld = $('#id_old').val()
        var idNew = $('#id_new').val()

        $('#veh_list').html(data)
        $('#recovery').addClass('d-none');
        document.getElementById("recovery_account_button").onclick = function() { recovery_account(idOld, idNew); };
        $('#result').removeClass('d-none');
        console.log($(this).serialize())
    })

    e.preventDefault()

})

function recovery_cancel(var1, var2) {
    location.reload();
}

function recovery_account(var1, var2) {

    $.ajax({
        url: '/data.php?arg=recoveryAccount',
        method: 'post',
        data: { 'idOld': var1, 'idNew': var2 }
    }).done(function(data) {

        let obj = JSON.parse(data);
        console.log(obj.status)

        if (obj.status) {
            var alertType = 'success';
            var alertTitle = 'Concluído';
        } else {
            var alertType = 'warning';
            var alertTitle = 'Erro';
        }

        // Alerta do retorno
        Swal.fire({
            position: 'center',
            type: alertType,
            title: alertTitle,
            text: obj.msg,
            showConfirmButton: true,
            timer: 6000
        })
        setTimeout(function() { location.reload(); }, 4000);

    });
}

var toggle_infos = false

$('#verMais').click(function(event) {
    event.preventDefault();
    toggle_infos = !toggle_infos
    if (toggle_infos == true) {
        $('#vips_infos').fadeIn();
        setTimeout(function() { $('#vips_infos').fadeOut(); }, 4000);
    } else {
        $('#vips_infos').fadeOut();
    }



});






// Submit carregar vips para mudanças trocas etc
$('#getVips').submit(function(e) {
    $.post('data.php?arg=getVipsChange', $(this).serialize(), function(data) {
        $('#inputId').hide();
        $('#tabela-vips').html(data);
        $('#listaVips').slideDown(500);
    })
    e.preventDefault()
})

function editVip(id) {

    $.ajax({
        url: '/data.php?arg=getVipInfo',
        method: 'post',
        data: { 'id': id }
    }).done(function(data) {

        let obj = JSON.parse(data);

        $('#vip_id').val(obj[0].id);
        $('#user_id').html(obj[0].user_id);
        $('#plano').html(obj[0].plano);
        $('#mansao').html(obj[0].mansao);

        let date = new Date(obj[0].criacao);
        options = {
            year: 'numeric',
            month: 'numeric',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: false
        };
        let dataCriacao = new Intl.DateTimeFormat('pt-br', options).format(date);
        $('#criacao').html(dataCriacao);

        // monta select dos carros vips
        var cars = obj[0].carros.split(',');

        var i;
        for (i = 0; i < cars.length; i++) {
            $('#listaCarros').tokenize2().trigger('tokenize:tokens:add', [cars[i], cars[i], true]);
        }

        // monta select das advs   
        $.ajax({
            url: '/data.php?arg=getDiscordId',
            method: 'post',
            data: { 'user_id': obj[0].user_id }
        }).done(function(data) {
            let advs = JSON.parse(data);

            // Preenche hidden id do discord do cara
            $('#discord_id').val(advs[0].discordId);
            $('#user_id').val(advs[0].discordId);

            var j;
            for (j = 0; j < advs.length; j++) {
                $('#advertencias').tokenize2().trigger('tokenize:tokens:add', [advs[j].id, advs[j].title, true]);
            }
        });

        $('#listaVips').fadeOut(0);
        $('#editVipCars').slideDown(500);

    });
}

function removeAdv(discordId, discordRoleId, userid) {
    $.ajax({
        url: '/discordAPI.php?arg=removeAdv',
        method: 'post',
        data: { 'discordId': discordId, 'discordRoleId': discordRoleId, 'user_id': userid }
    }).done(function(data) {
        //alert(data)
    });
}


// Configurações do multiselect
$(document).ready(function() {
    if (location.pathname == '/changes.html' || location.pathname == '/sets.html') {
        // Configurações
        $('#listaCarros').tokenize2({

            // max number of tags
            tokensMaxItems: 5,

            // allow you to create custom tokens
            tokensAllowCustom: true,

            // max items in the dropdown
            dropdownMaxItems: 20,

            // minimum/maximum of characters required to start searching
            searchMinLength: 3,
            searchMaxLength: 20,

            // specify if Tokenize2 will search from the begining of a string
            searchFromStart: true,

            // choose if you want your search highlighted in the result dropdown
            searchHighlight: true,

            // custom delimiter
            delimiter: ',',

            // display no results message
            displayNoResultsMessage: true,
            noResultsMessageText: 'Sem resultados "%s"',

            // custom delimiter
            delimiter: ',',

            // data source
            dataSource: 'carList.php',

            // waiting time between each search
            debounce: 0,

            // custom placeholder text
            placeholder: false,

            // enable sortable
            // requires jQuery UI
            sortable: false,

            // tabIndex
            tabIndex: 0,

            // allows empty values
            allowEmptyValues: false,

            // z-inde
            zIndexMargin: 500

        });

        // Define qual select 
        $('#listaCarros').tokenize2();
        $('#advertencias').tokenize2();

        // Função remover adv chamada ao remover item da lista
        $('#advertencias').on('tokenize:tokens:remove', function(e, value) {
            const idDiscord = $('#discord_id').val();
            const userid = parseInt($('#user_id').html(), 10);

            removeAdv(idDiscord, value, userid)
        });

    }
});

// Submit envio da troca dos carros
$('#changeCars').submit(function(e) {
    $.post('data.php?arg=changeCars', $(this).serialize(), function(data) {
        alert(data)
        location.reload();
    })
    e.preventDefault()
})