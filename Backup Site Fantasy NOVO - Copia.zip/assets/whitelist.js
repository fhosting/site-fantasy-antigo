if(location.pathname=='/whitelist.html'){$('#step1').submit(function(e){$('#page-top').loading('start')
$.post('controller/whitelist.php?arg=step1',$(this).serialize(),function(data){$('#page-top').loading('stop')
let ret=JSON.parse(data);if(ret.error==1){Swal.fire({position:'center',type:'warning',title:'Erro',text:ret.msg,showConfirmButton:false,timer:6000});}else{$('#step1').fadeOut(200);$('#step1').html('');$('#user_id').val(ret.id);setTimeout(function(){$('#step2').fadeIn(200);},200);}})
e.preventDefault()});$('#step2').submit(function(e){$('#page-top').loading('start')
$.post('controller/whitelist.php?arg=step2',$(this).serialize(),function(data){$('#page-top').loading('stop')
let ret=JSON.parse(data);if(ret.error==1){Swal.fire({position:'center',type:'warning',title:'Erro',text:ret.msg,showConfirmButton:false,timer:6000});}else{$('#step2').fadeOut(200);$.post('controller/whitelist.php?arg=requestQuestion',function(data){let questions=JSON.parse(data);let questionsHtml='<h3 class="text-warning text-right" id="steps">3/3</h3>';let cntQuestion=1;Object.keys(questions).forEach(key=>{questionsHtml=questionsHtml+'<p><b>'+cntQuestion+'. </b>'+questions[key].pergunta+'</p>';questionsHtml=questionsHtml+'<select class="form-control mb-4" name="'+key+'"><option value="0">'+questions[key].respostas[0].resposta+'</option><option value="1">'+questions[key].respostas[1].resposta+'</option ><option value="2" >'+questions[key].respostas[2].resposta+'</option><option value="3">'+questions[key].respostas[3].resposta+'</option></select>';questionsHtml=questionsHtml+'<input class="form-control" type="hidden" id="user_id2" name="user_id" value="'+$('#user_id').val()+'">';cntQuestion=cntQuestion+1;});questionsHtml=questionsHtml+'<div class="g-recaptcha mt-4 text-center" data-sitekey="6LfJloIUAAAAABH9uL0SkZH9RwpSPnKKVLbNdMb3"></div>';questionsHtml=questionsHtml+'<div class="form-group"><button class="btn btn-success btn-block mt-5" type="submit">VERIFICAR RESULTADO</button></div>';$('#step3').html(questionsHtml);$('#step3').fadeIn(200);grecaptcha.render($('.g-recaptcha')[0],{sitekey:'6LfJloIUAAAAABH9uL0SkZH9RwpSPnKKVLbNdMb3'});})}})
e.preventDefault()});$('#step3').submit(function(e){$('#page-top').loading('start')
$.post('controller/whitelist.php?arg=step3',$(this).serialize(),function(data){$('#page-top').loading('stop')
let ret=JSON.parse(data);if(ret.error==0){Swal.fire({position:'center',type:'success',title:'Aprovado!',html:ret.msg,showConfirmButton:false,timer:10000});}else{Swal.fire({position:'center',type:'warning',title:'Reprovado!',html:ret.msg,showConfirmButton:true,timer:10000});}
setTimeout(function(){location.reload();},10000);})
e.preventDefault()});}
if(location.pathname=='/questions.html'){$('#adicionar-pergunta').submit(function(e){if($('#verdadeiro0').val()=='true'||$('#verdadeiro1').val()=='true'||$('#verdadeiro2').val()=='true'||$('#verdadeiro3').val()=='true'){$('#page-top').loading('start')
$.post('controller/whitelist.php?arg=addQuestion',$(this).serialize(),function(data){$('#page-top').loading('stop')
obj=JSON.parse(data);if(obj.error==1){alertType='warning';alertTitle='Problema identificado'}else{alertType='success';alertTitle='Concluído';}
Swal.fire({position:'center',type:alertType,title:alertTitle,text:obj.msg,showConfirmButton:false,timer:6000})
setTimeout(function(){location.reload();},6000);});}else{Swal.fire({position:'center',type:'warning',title:'Problema na questão',text:'Uma das respostas necessita ser verdadeira!',showConfirmButton:true,timer:6000})}
e.preventDefault()});}
if(location.pathname=='/questions-list.html'){$('#page-top').loading('start')
$(document).ready(function(){$.ajax({url:'/controller/whitelist.php',method:'get',data:{arg:'questionsList'}}).done(function(data){$('#page-top').loading('stop')
let obj=JSON.parse(data)
let questions='';let cntQ=1;Object.keys(obj).forEach(key=>{questions=questions+'<div> <h5 class="d-inline-block">Pergunta N°&nbsp; </h5> <h5 class="d-inline-block">'+cntQ+'</h5><a style="cursor: pointer;" onclick = "editQuestion('+key+')"><i class="fa fa-edit ml-2" style="color:rgb(238,61,61);font-size: 20px;"></i ></a><p>'+obj[key].pergunta+'<br></p><hr></div>';cntQ=cntQ+1;});$('#questionList').html(questions);});});}
function editQuestion(id){window.location.href="/question-edit.html?arg=questionEdit&id="+id;}
if(location.pathname=='/question-edit.html'){$(document).ready(function(){$('#page-top').loading('start')
let questionId=new URLSearchParams(window.location.search).get('id');$('#quesID').val(questionId);$.ajax({url:'/controller/whitelist.php',method:'get',data:{arg:'questionEdit',id:questionId}}).done(function(data){$('#page-top').loading('stop')
let obj=JSON.parse(data)
$('#pergunta').val(obj[questionId].pergunta);$('#resposta0').val(obj[questionId].respostas[0].resposta);$('#resposta1').val(obj[questionId].respostas[1].resposta);$('#resposta2').val(obj[questionId].respostas[2].resposta);$('#resposta3').val(obj[questionId].respostas[3].resposta);$('#verdadeiro0').val(obj[questionId].respostas[0].verdadeiro);$('#verdadeiro1').val(obj[questionId].respostas[1].verdadeiro);$('#verdadeiro2').val(obj[questionId].respostas[2].verdadeiro);$('#verdadeiro3').val(obj[questionId].respostas[3].verdadeiro);});});}
if(location.pathname=='/question-edit.html'){$('#editar-pergunta').submit(function(e){if($('#verdadeiro0').val()=='true'||$('#verdadeiro1').val()=='true'||$('#verdadeiro2').val()=='true'||$('#verdadeiro3').val()=='true'){$('#page-top').loading('start')
$.post('controller/whitelist.php?arg=saveEdit',$(this).serialize(),function(data){$('#page-top').loading('stop')
obj=JSON.parse(data);if(obj.error==1){alertType='warning';alertTitle='Problema identificado'}else{alertType='success';alertTitle='Concluído';}
Swal.fire({position:'center',type:alertType,title:alertTitle,text:obj.msg,showConfirmButton:false,timer:6000})
setTimeout(function(){window.location.href="/questions-list.html"},6000);});}else{Swal.fire({position:'center',type:'warning',title:'Problema na questão',text:'Uma das respostas necessita ser verdadeira!',showConfirmButton:true,timer:6000})}
e.preventDefault()});}