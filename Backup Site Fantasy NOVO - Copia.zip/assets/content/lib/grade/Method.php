<?php

namespace assets\content\lib\grade;

use assets\content\lib\grade\Config;

class Method extends Config
{

  public static function alertError($type, $message)
  {

    $header = '';
    switch ($type) {
      case '404':
        $header = header("HTTP/1.0 404 Not Found");
        break;
    }

    $header;
    if (!defined("BASE_URL") && (!defined("SITE_NAME")) && (!defined("SITE_NAME_M"))) {
      define("BASE_URL", Config::BASE_URL);
      define("SITE_NAME_M", Config::SITE_NAME_M);
    }
    define("SITE_ERROR", $message);
    include("assets/content/lib/include/layouts/error.phtml");
    die();
    return;
  }

  public function limitBody($text, $limit, $break = true)
  {
    $accountant = strlen(strip_tags($text));
    if ($accountant <= $limit) :
      $newtext = $text;
    else :
      if ($break == true) :
        $newtext = trim(mb_substr($text, 0, $limit)) . " ...";
      else :
        $ultimo_espaco = strrpos(mb_substr($text, 0, $limit), " ");
        $newtext = trim(mb_substr($text, 0, $ultimo_espaco)) . " ...";
      endif;
    endif;
    return $newtext;
  }
}