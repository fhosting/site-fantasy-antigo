<?php

namespace assets\content\lib\grade;

use assets\content\lib\grade\Config;
use assets\content\lib\grade\Method;

class System extends Route
{
  public $config;

  private $url;
  private $exploder;
  private $area;
  private $controller;
  private $action;
  private $params;
  private $exeController;

  public function __construct()
  {
    $this->config = new Config();

    $this->defineUrl();
    $this->defineExploder();
    $this->defineArea();
    $this->defineController();
    $this->defineAction();
    $this->defineParams();
  }

  public function defineUrl()
  {
    $this->url = isset($_GET['url']) ? $_GET['url'] : 'home/index';
  }

  private function defineExploder()
  {
    $this->exploder = explode('/', $this->url);
  }

  private function defineArea()
  {
    foreach ($this->routes as $i => $v) {
      if ($this->onRaiz && $this->exploder[0] == $i) {
        $this->area = $v;
        $this->onRaiz = false;
      }
    }

    $this->area = empty($this->area) ? $this->routeOnRaiz : $this->area;

    if (!defined('APP_AREA')) {
      define('APP_AREA', $this->area);
    }
  }

  public function getArea()
  {
    return $this->area;
  }

  private function defineController()
  {
    $this->controller = $this->onRaiz ? $this->exploder[0] : (empty($this->exploder[1]) || is_null($this->exploder[1]) || !isset($this->exploder[1]) ? 'home' : $this->exploder[1]);
  }

  public function getController()
  {
    return $this->controller;
  }

  private function defineAction()
  {
    $this->action = $this->onRaiz ? (!isset($this->exploder[1]) || is_null($this->exploder[1]) || empty($this->exploder[1]) ? 'index' : $this->exploder[1]) : (!isset($this->exploder[2]) || is_null($this->exploder[2]) || empty($this->exploder[2]) ? 'index' : $this->exploder[2]);
  }

  public function getAction()
  {
    return $this->action;
  }

  private function defineParams()
  {
    if ($this->onRaiz) {
      unset($this->exploder[0], $this->exploder[1]);
    } else {
      unset($this->exploder[0], $this->exploder[1], $this->exploder[2]);
    }

    if (end($this->exploder) == null) {
      array_pop($this->exploder);
    }

    if (empty($this->exploder)) {
      $this->params = array();
    } else {
      foreach ($this->exploder as $val) {
        $params[] = $val;
      }
      $this->params = $params;
    }
  }

  public function getParams($indice)
  {
    return isset($this->params[$indice]) ? $this->params[$indice] : null;
  }

  private function validateController()
  {
    if (!(class_exists($this->exeController))) {
      Method::alertError('404', 'Could not find <span>' . $this->controller . '</span> controller.');
    }
  }

  private function validateAction()
  {
    if (!(method_exists($this->exeController, $this->action))) {
      Method::alertError('404', 'The <span>' . $this->action . '</span> method was not found.');
    }
  }

  public function setup()
  {
    $this->exeController = 'assets\\content\\lib\\controller\\' . $this->getArea() . '\\' . $this->controller . 'Control';
    $this->validateController();
    $this->exeController = new $this->exeController();

    $this->validateAction();
    $act = $this->action;
    $this->exeController->$act();
  }
}