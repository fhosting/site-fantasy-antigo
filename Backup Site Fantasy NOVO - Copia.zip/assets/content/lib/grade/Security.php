<?php

namespace assets\content\lib\grade;

class Security extends Config
{
  public static function connection()
  {
    if (strpos($_SERVER['HTTP_REFERER'], Config::DOMAIN)) {
      return true;
    }
    return strpos($_SERVER['HTTP_REFERER'], Config::DOMAIN);
  }
}