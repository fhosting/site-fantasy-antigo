<?php

namespace assets\content\lib\grade;

class Json
{

  public static function response($data)
  {
    header('Content-type: application/json; charset=utf-8');
    return json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  }

  public static function encode($data)
  {
    return json_encode($data);
  }

  public static function decode($data)
  {
    if (is_null($data)) {
      return ['error' => 'Error trying to decode'];
    }

    return (object) json_decode($data);
  }
}