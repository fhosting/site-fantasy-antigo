<?php

namespace assets\content\lib\grade;

class Config
{

  # web site
  // address
  const MACHINE = "fantasyhosting.com.br";
  const DOMAIN = "fantasyhosting.com.br";
  const BASE_URL = "https://fantasyhosting.com.br";

  const SITE_NAME = 'FantasyHost';
  const SITE_NAME_M = 'F.H.';

  # show erros
  const DEBUG = false;
}