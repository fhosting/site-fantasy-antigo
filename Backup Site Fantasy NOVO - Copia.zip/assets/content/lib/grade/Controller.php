<?php

namespace assets\content\lib\grade;

use assets\content\lib\grade\Config;
use assets\content\lib\grade\Method;

class Controller extends System
{
  public $BASE_URL = Config::BASE_URL;

  public $data;
  public $layout;
  public $config;

  private $path;
  private $pathRender;

  protected $sTitle;
  protected $sDescription;
  protected $sKeywords = SITE_KEYWORDS;
  protected $sColor = SITE_COLOR;
  protected $sFavicon = null;
  protected $sSoon = null;

  protected $captionController;
  protected $captionAction;
  protected $captioParams;

  // others

  protected $pageFileName;

  public function __construct()
  {
    parent::__construct();

    $this->config = new Config();
  }

  // [ FUNCTION ] - Path

  #define
  private function definePath($render)
  {
    if (is_array($render)) {
      foreach ($render as $li) {
        $path = 'assets/content/watch' . $this->getArea() . '/' . $this->getController() . '/' . $li . '.phtml';

        $this->fileExists($this->path, $this->getController(), $this->pathRender);
        $this->path[] = $path;
      }
    } else {
      $this->pathRender = is_null($render) ? $this->getAction() : $render;
      $this->path = 'assets/content/watch/' . $this->getArea() . '/' . $this->getController() . '/' . $this->pathRender . '.phtml';
      $this->fileExists($this->path, $this->getController(), $this->pathRender);
    }
  }

  #destruct
  public function destructPath()
  {
    unset($this->path);
    unset($this->pathRender);
  }

  // [FUNCTION] - Variables
  public function layout($type, $str = "")
  {
    $result = '';
    switch ($type) {
      case 'define':
        $result = $str;
        break;

      case 'remove':
        $result = null;
        break;
    }
    return $this->layout = $result;
  }

  // [FUNCTION] - General
  public function site($type, $str)
  {
    switch ($type) {
      case 'title':
        $this->sTitle = $str;
        break;
      case 'description':
        $this->sDescription = $str;
        break;
    }
  }

  // [FUNCTION] - Add Active
  public function addActive($type, $page)
  {

    $result = '';
    switch ($type) {

        // Controller
      case 'controller':
        $result = ($this->getController() == $page) ? 'active' : "";
        break;

        // Params
      case 'params':
        $result = ($this->getParams(0) == $page) ? 'active' : "";
        break;

        // Action
      case 'action':
        $result = ($this->getAction() == $page) ? 'active' : "";
        break;
    }

    return $result;
  }

  // [FUNCTION] - IMPORTS
  public function printImports()
  {
    return '
      <!-- # favicon -->
      <link rel="shortcut icon" type="image/png" href="'.Config::BASE_URL.'/assets/content/public/img/favicon.png" sizes="16x16">

      <!-- # css -->
      <link rel="stylesheet" href="/assets/content/public/css/utils/normalize.css">
      <link rel="stylesheet" href="/assets/content/public/css/style.css">
    
      <!-- # javascript -->
      <script src="/assets/content/public/js/jquery/jquery.min.js"></script>
      <script src="/assets/content/public/js/jquery/jquery-ui.min.js"></script>
    
      <script src="https://cdn.jsdelivr.net/npm/clipboard@1/dist/clipboard.min.js"></script>
      <link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.3.45/css/materialdesignicons.min.css">



      <!--
      *
        developed by geraldo moehra :-)

        instagram; gmoehra.16
        facebook; gm0ehra
        twitter; gmoehra
        discord; gmoehra#8251
      *
      -->
    ';
  }

  // [FUNCTION] - File Exists
  private function fileExists($file, $fileArea, $fileName)
  {
    if (!file_exists($file)) {
      Method::alertError('404', 'Could not find <span>' . $fileArea . '/' . $fileName . '</span> file.');
    }
  }

  // [FUNCTION] - View X page
  public function watch($render = null)
  {
    $this->sTitle = is_null($this->sTitle) ? 'My title' : $this->sTitle;
    $this->sDescription = is_null($this->sDescription) ? 'My description' : $this->sDescription;
    $this->sKeywords = is_null($this->sKeywords) ? 'My keywords' : $this->sKeywords;

    $this->definePath($render);

    if (is_null($this->layout)) {
      $this->render();
    } else {
      $this->layout = 'assets/content/lib/include/layouts/' . $this->layout . '.phtml';
      if (file_exists($this->layout)) {
        $this->render($this->layout);
      } else {
        Method::alertError('404', 'Could not find <span>' . $this->layout . '</span> layout.');
      }
    }
  }

  // FUNCTION - Render the content
  public function render($file = null)
  {
    if (is_array($this->data) && count($this->data) > 0) {
      extract($this->data, EXTR_PREFIX_ALL, 'watch');
      extract(array(
        'controller' => (is_null($this->captionController) ? '' : $this->captionController),
        'action' => (is_null($this->captionAction) ? '' : $this->captionAction),
        'params' => (is_null($this->captionParams) ? '' : $this->captionParams)
      ), EXTR_PREFIX_ALL, 'caption');
    }

    if (!is_null($file) && is_array($file)) {
      foreach ($file as $li) {
        include($li);
      }
    } elseif (is_null($file) && is_array($this->path)) {
      foreach ($this->path as $li) {
        include($li);
      }
    } else {
      $file = is_null($file) ? $this->path : $file;
      file_exists($file) ? include($file) : die($file);
    }
  }
}