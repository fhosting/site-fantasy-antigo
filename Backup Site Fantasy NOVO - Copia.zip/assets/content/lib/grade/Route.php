<?php

namespace assets\content\lib\grade;

class Route extends Config
{

  protected $routes = [
    'site' => 'site'
  ];

  protected $routeOnRaiz = 'site';
  protected $onRaiz = true;
}