<?php

namespace assets\content\lib\controller\site;

use assets\content\lib\grade\Config;
use assets\content\lib\grade\Json;
use assets\content\lib\grade\Security;
use assets\content\lib\grade\Controller;

/*
  API
*/
use assets\content\lib\grade\Method;

class cloudvpsControl extends Controller
{
  public $method, $config;

  public function __construct()
  {
    parent::__construct();

    $this->method = new Method();
    $this->config = new Config();

    $this->layout('define', 'draft');
    $this->site('title', 'Cloud & VPS - ' . SITE_NAME);
    $this->site('description', '');
  }

  public function index()
  {
    $this->watch();
  }
  public function br()
  {
    $this->watch('locale/br');
    $this->site('description', '[Brasil] Cloud & VPS - ' . SITE_NAME);
  }
  public function us()
  {
    $this->watch('locale/us');
    $this->site('description', '[US] Cloud & VPS - ' . SITE_NAME);
  }
}