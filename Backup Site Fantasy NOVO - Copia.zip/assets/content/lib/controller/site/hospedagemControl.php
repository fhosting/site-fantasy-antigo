<?php

namespace assets\content\lib\controller\site;

use assets\content\lib\grade\Json;
use assets\content\lib\grade\Security;
use assets\content\lib\grade\Controller;

/*
  API
*/
use assets\content\lib\grade\Method;

class hospedagemControl extends Controller
{
  public $method;

  public function __construct()
  {
    parent::__construct();

    $this->method = new Method();

    $this->layout('define', 'draft');
    $this->site('title', 'Hospedagem - ' . SITE_NAME);
    $this->site('description', '');
  }

  public function index()
  {
    $this->watch();
  }
  
  public function mcpe()
  {
    $this->watch('hospedagem/mcpe');
    $this->site('description', 'Hospedagem MC:PE ' . SITE_NAME);
  }
  
  public function nodejs()
  {
    $this->watch('hospedagem/nodejs');
    $this->site('description', 'Hospedagem NodeJS ' . SITE_NAME);
  }  
  
}