<?php

namespace assets\content\lib\controller\site;

use assets\content\lib\grade\Config;
use assets\content\lib\grade\Json;
use assets\content\lib\grade\Security;
use assets\content\lib\grade\Controller;

/*
  API
*/
use assets\content\lib\grade\Method;

class gtaControl extends Controller
{
  public $method, $config;

  public function __construct()
  {
    parent::__construct();

    $this->method = new Method();
    $this->config = new Config();

    $this->layout('define', 'draft');
    $this->site('title', 'GTA - ' . SITE_NAME);
    $this->site('description', '');
  }

  public function index()
  {
    $this->watch();
  }
  public function mta()
  {
    $this->watch('jogo/mta');
    $this->site('description', 'Hospedagem de MTA - ' . SITE_NAME);
  }
    public function samp()
  {
    $this->watch('jogo/samp');
    $this->site('description', 'Hospedagem de SAMP - ' . SITE_NAME);
  }
}