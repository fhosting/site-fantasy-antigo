<?php

namespace assets\content\lib\controller\site;

use assets\content\lib\grade\Config;
use assets\content\lib\grade\Json;
use assets\content\lib\grade\Security;
use assets\content\lib\grade\Controller;

/*
  API
*/
use assets\content\lib\grade\Method;

class servidoresControl extends Controller
{
  public $method, $config;

  public function __construct()
  {
    parent::__construct();

    $this->method = new Method();
    $this->config = new Config();

    $this->layout('define', 'draft');
    $this->site('title', 'Servidores - ' . SITE_NAME);
    $this->site('description', '');
  }

  public function index()
  {
    $this->watch();
  }
  public function dedicados()
  {
    $this->watch('dedicados/index');
    $this->site('description', 'Dedicados - ' . SITE_NAME);
  }
  public function dedicadosalema()
  {
    $this->watch('dedicadosalema');
    $this->site('description', '[GER] Dedicados - ' . SITE_NAME);
  }
  public function dedicadosca()
  {
    $this->watch('dedicadosca');
    $this->site('description', '[CA] Dedicados - ' . SITE_NAME);
  }  
  
}