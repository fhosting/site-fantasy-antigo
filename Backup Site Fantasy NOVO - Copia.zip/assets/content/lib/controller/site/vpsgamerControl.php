<?php

namespace assets\content\lib\controller\site;

use assets\content\lib\grade\Json;
use assets\content\lib\grade\Security;
use assets\content\lib\grade\Controller;

/*
  API
*/
use assets\content\lib\grade\Method;

class vpsgamerControl extends Controller
{
  public $method;

  public function __construct()
  {
    parent::__construct();

    $this->method = new Method();

    $this->layout('define', 'draft');
    $this->site('title', 'VPS Gamer - ' . SITE_NAME);
    $this->site('description', '');
  }

  public function index()
  {
    $this->watch();
  }

}