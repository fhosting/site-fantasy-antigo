<?php

namespace assets\content\lib\controller\site;

use assets\content\lib\grade\Json;
use assets\content\lib\grade\Security;
use assets\content\lib\grade\Controller;

/*
  API
*/
use assets\content\lib\grade\Method;

class revendasControl extends Controller
{
  public $method;

  public function __construct()
  {
    parent::__construct();

    $this->method = new Method();

    $this->layout('define', 'draft');
    $this->site('title', 'Revendas - ' . SITE_NAME);
    $this->site('description', '');
  }

  public function index()
  {
    $this->watch();
  }
  
  public function cpanelwhm()
  {
    $this->watch('cpanelwhm');
    $this->site('description', 'Revenda cPanel & WHM ' . SITE_NAME);
  }
  
  public function mtasamp()
  {
    $this->watch('mtasamp');
    $this->site('description', '[US] Revenda MTA & SAMP ' . SITE_NAME);
  }  
  public function mtasampbr()
  {
    $this->watch('mtasampbr');
    $this->site('description', '[BR] Revenda MTA & SAMP ' . SITE_NAME);
  }   
  public function vps()
  {
    $this->watch('vps');
    $this->site('description', 'Revenda VPS ' . SITE_NAME);
  }  
  public function masteralpha()
  {
    $this->watch('masteralpha');
    $this->site('description', 'Revenda Master & Alpha ' . SITE_NAME);
  }   
  
}