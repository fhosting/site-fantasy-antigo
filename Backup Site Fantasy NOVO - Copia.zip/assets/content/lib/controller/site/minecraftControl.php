<?php

namespace assets\content\lib\controller\site;

use assets\content\lib\grade\Json;
use assets\content\lib\grade\Security;
use assets\content\lib\grade\Controller;

/*
  API
*/
use assets\content\lib\grade\Method;

class minecraftControl extends Controller
{
  public $method;

  public function __construct()
  {
    parent::__construct();

    $this->method = new Method();

    $this->layout('define', 'draft');
    $this->site('title', 'Hospedagem Minecraft - ' . SITE_NAME);
    $this->site('description', '');
  }

  public function index()
  {
    $this->watch();
  }

  public function brasil()
  {
    $this->watch('locale/brasil');
    $this->site('description', '[Brasil] Hospedagem Minecraft - ' . SITE_NAME);
  }

  public function us()
  {
    $this->watch('locale/us');
    $this->site('description', '[US] Hospedagem Minecraft - ' . SITE_NAME);
  }
   public function miami()
  {
    $this->watch('locale/miami');
    $this->site('description', '[MIA] Hospedagem Minecraft - ' . SITE_NAME);
  } 
  

  public function mcpe()
  {
    $this->watch('mcpe');
    $this->site('description', 'Hospedagem MC:PE - ' . SITE_NAME);
  }  
}