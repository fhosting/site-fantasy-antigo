/* ////////////////////
 * SYSTEMS JAVASCRIPT *
 /////////////////// */

// button click 
function goTo(str, boolean) {
  if (boolean) { return window.open(str, "_blank", 'noopener'); }
  window.location.href = str;
}

// back to top
$('button.back_top').on('click', function (e) {
  e.preventDefault();

  $('html,body').animate({ scrollTop: 0 }, 700);
});

// click open widget
$(document).ready(function () {
  $("[data-show]").on('click', function () {
    let dataShow = $(this).attr("data-show");
    let dataRef = $(document).find("[data-show-ref='" + dataShow + "']");
    let dataSw = $(document).find("[data-show='" + dataShow + "']");

    if (typeof dataRef !== typeof undefined) {
      $(document).find(dataRef).slideToggle('medium');
      dataRef.toggleClass('active');
      dataSw.toggleClass('active');
    }
  });


  // menu mobile open
  $(".mobile button").click(function () {
    let body = $(document).find('body');

    if (document.getElementById('mask')) {
      body.removeAttr('id');
    } else {
      body.attr('id', 'mask');
    }
  });
});

// menu fixed
$(document).scroll(function () {
  let isMobile = window.matchMedia("only screen and (max-width: 760px)").matches;

  if (!isMobile) {
    //Conditional script here
    var navbar = $('menu[type="higher"]');

    if ($(document).scrollTop() >= 300) {
      navbar.addClass('fixed');
    } else {
      navbar.removeClass('fixed');
      navbar.fadeIn();
    }
  }
});